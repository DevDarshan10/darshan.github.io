﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using Microsoft.Office.Interop.PowerPoint;


namespace GameDev
{
    public partial class Form1 : Form
    {
        SpeechRecognitionEngine s = new SpeechRecognitionEngine();
        SpeechSynthesizer a = new SpeechSynthesizer();
        Microsoft.Office.Interop.PowerPoint.Application app = new Microsoft.Office.Interop.PowerPoint.Application();
        Slide slide;
        Presentation pre;
        SlideShowWindow show;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Choices choices = new Choices(new string[] {"hey jarvis","next slide","previous slide","hello World","open presentation","start slideshow"});
            GrammarBuilder gBuilder = new GrammarBuilder(choices);
            Grammar grammar = new Grammar(gBuilder);
            s.LoadGrammar(grammar);
            s.SetInputToDefaultAudioDevice();
            s.RecognizeAsync(RecognizeMode.Multiple);
            s.SpeechRecognized += s_SpeechRecognized;

        }

        private void s_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            a.SelectVoiceByHints(VoiceGender.Female);
            switch (e.Result.Text)
            {
                case "hey jarvis":
                    a.Speak("Hi I'm Jarvis How can I Help");
                    break;
                case "next slide":
                    pre.SlideShowWindow.View.Next();
                    break;
                case "previous slide":
                    pre.SlideShowWindow.View.Previous();
                    break;
                case "hello World":
                    a.Speak("Hello World");
                    break;
                case "open presentation":
                    a.Speak("Opening presentation");
                    pre = app.Presentations.Open(@""+textBox1.Text);
                    break;
                case "start slideshow":
                    a.Speak("Starting slide show");
                    pre.SlideShowSettings.Run();
                    break;
            }
        }
    }
}
